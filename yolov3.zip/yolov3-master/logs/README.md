Here is the Tensorboard log file that tracks many indicator of training process.
Because of the kernel living time limited, we failed to train the model for more than 14 epochs.
Given the mAP calculated in the training process, we choosed the epoch-13 model for testing.
