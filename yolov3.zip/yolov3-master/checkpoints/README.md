The model is too big, and it cannot be upload to Github by normal means.
We try to solve this by use the git-lfs uploading process.

If the model cannot be load into the YOLO net, you can turn to the BaiduYun:

This should be a integrate model, thanks a lot.
